It took about 2 hours to finish.

I didn't make it object oriented.